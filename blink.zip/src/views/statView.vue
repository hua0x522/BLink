<template>
  <v-container>
    <chart-block></chart-block>
  </v-container>
</template>

<script>
import ChartBlock from '../components/ChartBlock'
export default {
    data() {
        return {

        }
    },
    components: {
      ChartBlock
    }
}
</script>
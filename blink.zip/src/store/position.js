let position = {
    namespaced: true,
    state: {
        positions: []
    }
};

export default position;
let user = {
    namespaced: true,
    state: {
        real_name: "王雪竹",
        username: "wxz",
        islogin: false,
        password: "123456",
        sex: "男",
        status:"",
        type: "0",
        student: {
            school_name:"",
            grade:"",
            major:""
        },
        teacher: {
            profession_title:"",
            research_direction:"",
            lab_belonging:""
        },
        alumni: {
            school_name:"",
            work_field:"",
            enterprise_belonging:""
        }
    },
    mutations: {

    },
    actions: {

    }
};

export default user;
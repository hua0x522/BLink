let resume = {
    namespaced: true,
    state: {
        resumes: []
    }
};

export default resume;